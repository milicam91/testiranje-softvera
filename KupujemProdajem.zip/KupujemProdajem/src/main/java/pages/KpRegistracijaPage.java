package pages;

import org.openqa.selenium.WebDriver;
import locators.Locators;

public class KpRegistracijaPage extends BasePage {


    public KpRegistracijaPage(WebDriver driver) {
        super(driver);
    }

    public void unesiEmail(String email) {
        driver.findElement(Locators.EMAIL_INPUT).sendKeys(email);
    }

    public void klikniNastavite() {
        driver.findElement(Locators.DUGME_NASTAVITE).click();
    }


    public String dohvatiPorukuGreske() {
        return driver.findElement(Locators.PORUKA_GRESKE).getText();
    }
}