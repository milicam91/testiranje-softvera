package pages;

import org.openqa.selenium.WebDriver;
import locators.Locators;

public class KpHomePage extends BasePage {


    public KpHomePage(WebDriver driver) {
        super(driver);
    }

    public void klikniNaRegistrujSe() {
        driver.findElement(Locators.DUGME_REGISTRUJ_SE).click();
    }


    public void klikniNastaviRucno() {
        driver.findElement(Locators.DUGME_NASTAVI_RUČNO).click();
    }

    public void klikniNaPraznuPretragu() {
        driver.findElement(Locators.POLJE_PRETRAGE).click();
        driver.findElement(Locators.DUGME_ZA_PRETRAGU).click();
    }


    public String dohvatiTrenutniUrl() {
        return driver.getCurrentUrl();
    }
}