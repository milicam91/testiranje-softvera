package locators;

import org.openqa.selenium.By;

public class Locators {
    // Dugme registruj se na home page-u
    public static final By DUGME_REGISTRUJ_SE = By.xpath("//*[@id='__next']/div[1]/div[2]/div[1]/div/div/div/div/ul/li[5]/a/span");
    // Dugme "Nastavite ručno" / Registracija preko email-a nakon klika na home page-u
    public static final By DUGME_NASTAVI_RUČNO = By.xpath("//*[@id='__next']/div[1]/div[2]/div/main/section/section/div/div[3]/a");
    // Polje za unos email adrese
    public static final By EMAIL_INPUT = By.xpath("//*[@id='email']");

    // Dugme nastavite nakon unosa email adrese
    public static final By DUGME_NASTAVITE = By.xpath("//*[@id='__next']/div[1]/div[2]/div/main/section/div[1]/section/div/form/button/span");

    // Poruka da nije moguće nastaviti jer nije ispravan email
    public static final By PORUKA_GRESKE = By.xpath("//*[@id='__next']/div[1]/div[2]/div/main/section/div[1]/section/div/form/div/div");

    // Polje za unos pretrage koje si izvukla
    public static final By POLJE_PRETRAGE = By.xpath("//*[@id='keywords']");

    // Dugme za pretragu koje si izvukla
    public static final By DUGME_ZA_PRETRAGU = By.xpath("//*[@id='__next']/div[1]/div[1]/div/div/div[2]/div/form/section/div/div[1]/div/section/section/div/span[2]/button/span/*[local-name()='svg']");
}