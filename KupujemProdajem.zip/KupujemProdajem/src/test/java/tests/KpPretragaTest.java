package tests;

import base.BaseTest;
import org.junit.jupiter.api.Test;
import pages.KpHomePage;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class KpPretragaTest extends BaseTest {

    @Test
    public void testPraznaPretragaNaHomeStrani() {

        driver.get("https://www.kupujemprodajem.com/");


        KpHomePage homePage = new KpHomePage(driver);


        homePage.klikniNaPraznuPretragu();


        String ocekivaniUrl = "https://www.kupujemprodajem.com/";
        String stvarniUrl = homePage.dohvatiTrenutniUrl();

        assertEquals(ocekivaniUrl, stvarniUrl, "Greška: Sajt je promenio stranicu ili osvežio pretragu iako je polje prazno!");
    }
}