package tests;

import base.BaseTest;
import org.junit.jupiter.api.Test;
import pages.KpHomePage;
import pages.KpRegistracijaPage;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class KpRegistracijaTest extends BaseTest {

    @Test
    public void testNeispravanEmailRegistracija() {

        driver.get("https://www.kupujemprodajem.com/");


        KpHomePage homePage = new KpHomePage(driver);
        KpRegistracijaPage registracijaPage = new KpRegistracijaPage(driver);


        homePage.klikniNaRegistrujSe();


        homePage.klikniNastaviRucno();


        registracijaPage.unesiEmail("test@");
        registracijaPage.klikniNastavite();


        String stvarnaPorukaGreske = registracijaPage.dohvatiPorukuGreske();
        String ocekivanaPorukaGreske = "Niste uneli ispravan format e-mail adrese.";

        assertEquals(ocekivanaPorukaGreske, stvarnaPorukaGreske, "Poruka o grešci se ne poklapa sa očekivanom!");
    }
}