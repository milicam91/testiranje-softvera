package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AppTest {

    private WebDriver driver;

    @Before
    public void setUp() {

        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testCategoryNavigationAndBreadcrumb() throws Exception {

        driver.get("https://www.kupujemprodajem.com");

        Thread.sleep(5000);

        WebElement mobilni =
                driver.findElement(By.linkText("Mobilni telefoni"));

        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", mobilni);

        Thread.sleep(5000);

        System.out.println("URL: " + driver.getCurrentUrl());

        System.out.println("TITLE: " + driver.getTitle());

        System.out.println(
                driver.findElement(By.tagName("body")).getText()
        );
    }

    @After
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}