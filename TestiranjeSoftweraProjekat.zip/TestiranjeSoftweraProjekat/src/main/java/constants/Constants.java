package constants;

public class Constants {


    public static final String KP_URL = "https://www.kupujemprodajem.com";


    public static final String SEARCH_PRODUCT = "iPhone 13";


    public static final int MIN_PRICE = 200;
    public static final int MAX_PRICE = 600;

}
