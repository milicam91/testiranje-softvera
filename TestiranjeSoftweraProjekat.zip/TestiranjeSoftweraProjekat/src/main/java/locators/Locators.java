package locators;
import org.openqa.selenium.By;
public class Locators {

    public static final By KP_SEARCH =
            By.xpath("//input[contains(@name,'search') or contains(@name,'keyword')]");


    public static final By KP_FIRST_AD =
            By.xpath("(//a[contains(@href,'pClick.php')])[1]");


    public static final By KP_TITLE =
            By.xpath("//h1");


    public static final By KP_PRICE =
            By.xpath("//h2[contains(text(),'€') or .//text()[contains(.,'€')]]");


    public static final By KP_FIRST_AD_IMAGE =
            By.xpath("(//a//img)[1]");

    public static final By KP_PRICE_FROM =
            By.xpath("//input[@name='price_from' or contains(@placeholder,'od')]");

    public static final By KP_PRICE_TO =
            By.xpath("//input[@name='price_to' or contains(@placeholder,'do')]");


}
