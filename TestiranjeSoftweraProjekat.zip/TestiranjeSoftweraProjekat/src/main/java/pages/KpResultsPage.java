package pages;

import locators.Locators;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class KpResultsPage extends BasePage {

    public KpResultsPage(WebDriver driver) {
        super(driver);
    }


    public void openFirstAd() {

        WebElement firstAd = wait.until(
                ExpectedConditions.elementToBeClickable(Locators.KP_FIRST_AD)
        );

        firstAd.click();
    }

    public KpResultsPage applySearch() {
        driver.findElement(Locators.KP_SEARCH).submit();
        return new KpResultsPage(driver);
    }

}