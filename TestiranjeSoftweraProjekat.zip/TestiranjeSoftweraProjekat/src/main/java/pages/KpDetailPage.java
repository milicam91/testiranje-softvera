package pages;

import constants.Constants;
import locators.Locators;
import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class KpDetailPage extends BasePage {

    public KpDetailPage(WebDriver driver) {
        super(driver);
    }


    // Uzima naslov oglasa
    public String getTitle() {
        return getTextOf(Locators.KP_TITLE);
    }


    // Provera da li je naslov odgovarajući
    public KpDetailPage verifyTitle() {

        assertTrue(
                getTitle().toLowerCase().contains("iphone"),
                "Naslov oglasa ne sadrži iPhone"
        );


        System.out.println("TITLE: " + getTitle());
        System.out.println("URL: " + driver.getCurrentUrl());
        return this;
    }


    // Uzima cenu i pretvara je u broj
    public int getPrice() {

        String priceText = getTextOf(Locators.KP_PRICE);

        System.out.println("RAW PRICE TEXT: " + priceText);

        String cleanPrice = priceText.replaceAll("[^0-9]", "");

        int price = Integer.parseInt(cleanPrice);

        System.out.println("PARSED PRICE: " + price);

        return price;
    }



    public KpDetailPage verifyPrice() {

        int price = getPrice();

        try {
            assertTrue(
                    price >= Constants.MIN_PRICE &&
                            price <= Constants.MAX_PRICE,
                    "Namerno pogrešan opseg"
            );
        } catch (AssertionError e) {

            System.out.println("ASSERT FAILED - TAKING SCREENSHOT");

            throw e;
        }

        return this;
    }
}