package pages;

import constants.Constants;
import locators.Locators;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class KpHomePage extends BasePage {


    public KpHomePage(WebDriver driver) {
        super(driver);
    }

    // Otvaranje sajta Kupujem Prodajem
    public KpHomePage open() {
        driver.get(Constants.KP_URL);
        return this;
    }

    public KpHomePage searchProduct(String text) {

        WebElement search = waitForVisible(Locators.KP_SEARCH);

        search.clear();
        search.sendKeys(text);
        search.sendKeys(Keys.ENTER);

        return this;
    }

    public KpHomePage setMinPrice(int min) {
        sendKeys(Locators.KP_PRICE_FROM, String.valueOf(min));
        return this;
    }

    public KpHomePage setMaxPrice(int max) {
        sendKeys(Locators.KP_PRICE_TO, String.valueOf(max));
        return this;
    }




}