package base;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;


import java.io.File;
import java.io.IOException;

public class BaseTest {

    protected WebDriver driver;
    public ExtentReports extent;
    public ExtentTest test;

    @BeforeEach
    public void setup() {


        System.setProperty(
                "webdriver.edge.driver",
                "C:\\Users\\bogda\\Desktop\\FAKS\\Testiranje\\edgedriver\\msedgedriver.exe"
        );

        driver = new EdgeDriver();


        driver.manage().window().maximize();

        ExtentSparkReporter spark = new ExtentSparkReporter("target/report.html");
        extent = new ExtentReports();
        extent.attachReporter(spark);

        test = extent.createTest("KupujemProdajem Test");
    }


    @AfterEach
    public void tearDown() {


        if (driver != null) {
            driver.quit();
        }
        extent.flush();
    }





    public String takeScreenshot(String name) {

        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            File dir = new File("target/screenshots");
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String path = "target/screenshots/" + name + ".png";

            FileHandler.copy(src, new File(path));

            System.out.println("Screenshot saved: " + path);

            return path;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


}