import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class KupujemProdajemTest {

    @Test
    public void TC1() throws InterruptedException {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\bogda\\Desktop\\FAKS\\Testiranje\\edgedriver\\msedgedriver.exe");

        WebDriver driver = new EdgeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.manage().window().maximize();
        driver.get("https://www.kupujemprodajem.com");

        // 1. PRETRAGA
        WebElement search = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector("input[type='search'], input[name='search'], input")
                )
        );

        search.sendKeys("iPhone 13");
        search.sendKeys(Keys.ENTER);

        // 2. MALO ČEKANJE DA SE UČITA LISTA
        wait.until(ExpectedConditions.urlContains("pretraga"));

        // 3. UZIMANJE PRVOG OGLASA PREKO SLIKE
        WebElement firstAd = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.xpath("(//a[.//img])[1]")
                )
        );

        firstAd.click();

        // 4. PROVERA NASLOVA
        WebElement title = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.tagName("h1"))
        );

        String titleText = title.getText();
        System.out.println("TITLE: " + titleText);

        assertTrue(titleText.toLowerCase().contains("iphone"));

        // 5. PROVERA CENE
        List<WebElement> priceElements = driver.findElements(
                By.xpath("//*[contains(text(),'€')]")
        );

        if (priceElements.isEmpty()) {
            throw new RuntimeException("Cena nije pronađena");
        }

        String priceText = priceElements.get(0).getText();
        System.out.println("PRICE RAW: " + priceText);

        String cleaned = priceText.replaceAll("[^0-9]", "");

        if (!cleaned.isEmpty()) {
            int priceValue = Integer.parseInt(cleaned);
            assertTrue(priceValue >= 200 && priceValue <= 600);
        }

        driver.quit();
    }
}