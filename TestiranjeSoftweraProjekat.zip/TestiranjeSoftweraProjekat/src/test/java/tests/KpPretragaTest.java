package tests;

import base.BaseTest;
import constants.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pages.KpDetailPage;
import pages.KpHomePage;
import pages.KpResultsPage;

public class KpPretragaTest extends BaseTest {

    KpHomePage home;
    KpResultsPage results;
    KpDetailPage detail;

    @BeforeEach
    public void setUpPages() {
        home = new KpHomePage(driver);
        results = new KpResultsPage(driver);
        detail = new KpDetailPage(driver);
    }





    @Test
    public void testPretragaIphone() {

        try {
            test.info("Otvaram sajt");

            home.open()
                    .searchProduct(Constants.SEARCH_PRODUCT)
                    .setMinPrice(Constants.MIN_PRICE)
                    .setMaxPrice(Constants.MAX_PRICE);

            test.info("Otvaram prvi oglas");

            results.openFirstAd();

            test.info("Provera");

            detail.verifyTitle()
                    .verifyPrice();

        } catch (Throwable e) {

            test.fail(e.getMessage());

            takeScreenshot("error_" + System.currentTimeMillis());

            throw e;
        }
    }
}